table(position,[id,px,py]).
position(c1,350,140).
position(c4,350,350).
position(c3,140,140).
position(c2,840,343).
position(c6,350,980).
position(c0,980,980).
position(c5,140,980).

