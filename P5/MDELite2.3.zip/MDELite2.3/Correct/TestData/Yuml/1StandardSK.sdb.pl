table(position,[id,x,y]).
position(c1,50,20).
position(c4,50,50).
position(c3,20,20).
position(c2,120,49).
position(c6,50,140).
position(c0,140,140).
position(c5,20,140).
