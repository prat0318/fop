public interface state {
    public state gotocircularinitialstatenode0();
    public state gotocircularfinalstatenode0();
    public state gotoloop();
    public String getName();
}


