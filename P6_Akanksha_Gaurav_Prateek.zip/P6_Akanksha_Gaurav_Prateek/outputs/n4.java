public class n4 implements state {

    public state gotocircularinitialstatenode0() {
        return this;
    }

    public state goton1() {
        return this;
    }

    public state goton2() {
        return this;
    }

    public state goton3() {
        return this;
    }

    public state goton4() {
        return this;
    }

    public state gotocircularfinalstatenode0() {
        return new circularfinalstatenode0();
    }

    public String getName() {
        return "n4";
    }
	
}
