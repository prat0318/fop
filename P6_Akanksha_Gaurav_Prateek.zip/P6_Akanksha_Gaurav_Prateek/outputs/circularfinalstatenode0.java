public class circularfinalstatenode0 implements state {

    public state gotocircularinitialstatenode0() {
        return this;
    }

    public state gotocircularfinalstatenode0() {
        return this;
    }

    public state gotoloop() {
        return this;
    }

    public String getName() {
        return "circularfinalstatenode0";
    }
	
}
