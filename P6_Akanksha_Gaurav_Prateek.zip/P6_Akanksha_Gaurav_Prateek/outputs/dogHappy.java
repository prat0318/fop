public class dogHappy implements state {

    public state gotocircularinitialstatenode0() {
        return this;
    }

    public state gotocircularfinalstatenode0() {
        return new circularfinalstatenode0();
    }

    public state gotodogAwake() {
        return this;
    }

    public state gotodogHungry() {
        return this;
    }

    public state gotodogBowBow() {
        return this;
    }

    public state gotodonPats() {
        return this;
    }

    public state gotodogHappy() {
        return this;
    }

    public String getName() {
        return "dogHappy";
    }
	
}

