public class circularinitialstatenode0 implements state {

    public state gotocircularinitialstatenode0() {
        return this;
    }

    public state gotocircularfinalstatenode0() {
        return this;
    }

    public state gotoloop() {
        return new loop();
    }

    public String getName() {
        return "circularinitialstatenode0";
    }
	
}
