public interface common {
    public void gotocircularinitialstatenode0();
    public void gotocircularfinalstatenode0();
    public void gotoloop();
    public String getName();
}
