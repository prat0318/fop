public class circularinitialstatenode0 implements state {

    public state gotocircularinitialstatenode0() {
        return this;
    }

    public state gotos1() {
        return new s1();
    }

    public state gotos2() {
        return this;
    }

    public state gotocircularfinalstatenode0() {
        return this;
    }

    public String getName() {
        return "circularinitialstatenode0";
    }
	
}
