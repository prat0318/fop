public interface state {
    public state gotocircularinitialstatenode0();
    public state gotos1();
    public state gotos2();
    public state gotocircularfinalstatenode0();
    public String getName();
}


