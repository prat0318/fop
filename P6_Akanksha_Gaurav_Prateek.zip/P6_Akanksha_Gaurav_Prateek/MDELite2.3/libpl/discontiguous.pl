/** file   discontiguous.pl -- eliminates aggrevating warnings 
*   about tuples of a table not being listed sequentially **/

:- discontiguous table/2.

