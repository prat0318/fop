:-['swiplInstalled.pl'],tell('Errors.txt'),run,told,halt.
