run :- writeln('swipl program can be called!  You are ready to go!').
run.
