/* file removePosition.pl --  this file projects (removes) the position table from a SDB. */

run:-printTables([class, association, interface, classImplements, interfaceExtends]).
