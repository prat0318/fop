package FSMLite;
public class Main {
	public static void main(String[] argv){
		System.out.println(argv[0]);
		Convert.toPL(argv[0]);
                Convert.toSDB(argv[0]);
                Convert.toJAVA(argv[0]);
	}
}
