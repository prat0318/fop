/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package MDELite;
/**
 *
 * @author dsb -- this is a delegate class/facade for MDELite
 */
public class vm2t {
    public static void main(String[] args) {
        CoreMDELite.vm2t.Main.main(args);
    }
}
