public interface common {
    public void gotocircularinitialstatenode0();
    public void gotos1();
    public void gotos2();
    public void gotocircularfinalstatenode0();
    public String getName();
}
