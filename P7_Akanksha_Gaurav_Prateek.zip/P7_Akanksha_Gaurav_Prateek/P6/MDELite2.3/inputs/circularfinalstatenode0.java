public class circularfinalstatenode0 implements state {

    public state gotocircularinitialstatenode0() {
        return this;
    }

    public state gotos1() {
        return this;
    }

    public state gotos2() {
        return this;
    }

    public state gotocircularfinalstatenode0() {
        return this;
    }

    public String getName() {
        return "circularfinalstatenode0";
    }
	
}

