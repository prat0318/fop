public class circularinitialstatenode0 implements state {

    public state gotocircularinitialstatenode0() {
        return this;
    }

    public state gotocircularfinalstatenode0() {
        return this;
    }

    public state gotodogAwake() {
        return new dogAwake();
    }

    public state gotodogHungry() {
        return this;
    }

    public state gotodogBowBow() {
        return this;
    }

    public state gotodonPats() {
        return this;
    }

    public state gotodogHappy() {
        return this;
    }

    public String getName() {
        return "circularinitialstatenode0";
    }
	
}
