public interface common {
    public void gotocircularinitialstatenode0();
    public void gotocircularfinalstatenode0();
    public void gotodogAwake();
    public void gotodogHungry();
    public void gotodogBowBow();
    public void gotodonPats();
    public void gotodogHappy();
    public String getName();
}
