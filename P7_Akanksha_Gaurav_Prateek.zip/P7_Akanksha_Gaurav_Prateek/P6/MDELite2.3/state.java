public interface state {
    public state gotocircularinitialstatenode0();
    public state gotocircularfinalstatenode0();
    public state gotodogAwake();
    public state gotodogHungry();
    public state gotodogBowBow();
    public state gotodonPats();
    public state gotodogHappy();
    public String getName();
}


