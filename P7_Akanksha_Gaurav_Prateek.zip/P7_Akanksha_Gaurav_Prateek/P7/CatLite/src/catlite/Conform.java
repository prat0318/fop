/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package catlite;

/**
 *
 * @author prat0318
 */
public class Conform {
    public static void main(String args[]) {
        Violet v = new Violet(args[1]);
    }
}
