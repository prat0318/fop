package quark;

abstract class H extends tree {

   // set of methods common to all higher-order advice
 
   /**
 * @deprecated Use {@link quark.Visitor#visit(A, I)} instead
 */
public tree accept( Visitor v, I i ) {
	return v.visit(this, i);
}

   public tree apply( A a ) {
      System.out.println( "cannot apply local advice to higher order advice" );
      System.exit(1);
      return null;
   }

   public tree apply( G g ) {
      System.out.println( "cannot apply global advice to higher order advice" );
      System.exit(1);
      return null;
   }
}
