package quark;

class intro extends I {
   String name;

   intro(String name) { this.name = name; }

   /**
 * @deprecated Use {@link quark.Visitor#visit(quark.intro,I)} instead
 */
public tree accept( Visitor v, I i ) {
	return v.visit(this, i);
}

   public tree apply( A a ) { return new advprog( a, this ); }

   public tree apply( G g ) { return new gadvprog( g, this ); }

   public tree apply( H h ) { return this; }
   
   public String toString() { return name; }

   public String eval( String fnc ) { return fnc + name; }
}
