package quark;

class gadvprog extends I {
   G left;
   I right;

   gadvprog( G left, I right ) { this.left = left; this.right = right; }

   /**
 * @deprecated Use {@link quark.Visitor#visit(quark.gadvprog,I)} instead
 */
public tree accept(Visitor v, I i) {
	return v.visit(this, i);
}

   public tree apply(A a) { return new gadvprog( left, (I) right.apply(a)); }

   public tree apply( G g ) { return new gadvprog(new gadvsum(g,left), right) ; }

   public tree apply(H h) { return new gadvprog((G) left.apply(h), (I) right.apply(h)); }

   public String toString() { return left + "(" + right + ")"; }

   public String eval( String fnc ) {  return right.eval(fnc+left.eval("")); }
}
