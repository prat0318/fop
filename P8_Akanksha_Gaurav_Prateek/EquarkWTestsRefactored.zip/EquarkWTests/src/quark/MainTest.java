package quark;

import org.junit.Test;

/**
*
* @author dsb
*/
public class MainTest {
    Main m;
    
    public MainTest() {
        m = new Main("quark.Main");
    }

    @Test
    public void general1() {
        m.clearModuleExpression();
        m.setModelType("General",true);
        m.applyQuark();
        String fe = m.getFeatureExpression();
        String me = m.getModuleExpression();
        String p  = m.getProgram();
        assert(fe.equals("F1(Base)"));
        assert(me.equals("p\ng1(i1 + a1(p))"));
        assert(p.equals("g1i1 + g1a1p"));
    }
    
    @Test
    public void general2() {
        general1();
        m.applyQuark();
        m.applyQuark();
        String fe = m.getFeatureExpression();
        String me = m.getModuleExpression();
        String p  = m.getProgram();
        assert(fe.equals("F3(F2(F1(Base)))"));
        assert(me.equals("p\n" +"g1(i1 + a1(p))\n" +"g2 . h2[g1](i2 + a2(i1 + h2[a1](p)))\n" +
                "g3 . h3[g2 . h2[g1]](i3 + a3(i2 + h3[a2](i1 + h3 * h2[a1](p))))"));
        assert(p.equals("g3h3g2h3h2g1i3 + g3h3g2h3h2g1a3i2 + g3h3g2h3h2g1a3h3a2i1 + g3h3g2h3h2g1a3h3a2h3h2a1p"));
    }
    
    @Test
    public void AHEAD1() {
        m.clearModuleExpression();
        m.setModelType("Ahead", true);
        m.applyQuark();
        String fe = m.getFeatureExpression();
        String me = m.getModuleExpression();
        String p  = m.getProgram();
        assert(fe.equals("F1(Base)"));
        assert(me.equals("p\n" +"i1 + a1(p)"));
        assert(p.equals("i1 + a1p"));
    }
    
    @Test
    public void AHEAD2() {
        AHEAD1();
        m.applyQuark();
        m.applyQuark();
        String fe = m.getFeatureExpression();
        String me = m.getModuleExpression();
        String p  = m.getProgram();
        assert(fe.equals("F3(F2(F1(Base)))"));
        assert(me.equals("p\n" +"i1 + a1(p)\n" +"i2 + a2(i1 + a1(p))\n" +"i3 + a3(i2 + a2(i1 + a1(p)))"));
        assert(p.equals("i3 + a3i2 + a3a2i1 + a3a2a1p"));
    }
        
    
    @Test
    public void AML1() {
        m.clearModuleExpression();
        m.setModelType("Aspectual Mixin Layers++", true);
        m.applyQuark();
        String fe = m.getFeatureExpression();
        String me = m.getModuleExpression();
        String p  = m.getProgram();
        assert(fe.equals("F1(Base)"));
        assert(me.equals("p\n" +"g1(i1 + p)"));
        assert(p.equals("g1i1 + g1p"));
    }
    
    @Test
    public void AML2() {
        AML1();
        m.applyQuark();
        m.applyQuark();
        String fe = m.getFeatureExpression();
        String me = m.getModuleExpression();
        String p  = m.getProgram();
        assert(fe.equals("F3(F2(F1(Base)))"));
        assert(me.equals("p\n" +  "g1(i1 + p)\n" + "g2 . h2[g1](i2 + i1 + p)\n" +
               "g3 . h3[g2 . h2[g1]](i3 + i2 + i1 + p)"));
        assert(p.equals("g3h3g2h3h2g1i3 + g3h3g2h3h2g1i2 + g3h3g2h3h2g1i1 + g3h3g2h3h2g1p"));
    }
    
    @Test
    public void AspectJ1() {
        m.clearModuleExpression();
        m.setModelType("AspectJ", true);
        m.applyQuark();
        String fe = m.getFeatureExpression();
        String me = m.getModuleExpression();
        String p  = m.getProgram();
        assert(fe.equals("F1(Base)"));
        assert(me.equals("p\n" +"g1(i1 + p)"));
        assert(p.equals("g1i1 + g1p"));
    }
    
    @Test
    public void AspectJ2() {
        AspectJ1();
        m.applyQuark();
        m.applyQuark();
        String fe = m.getFeatureExpression();
        String me = m.getModuleExpression();
        String p  = m.getProgram();
        assert(fe.equals("F3(F2(F1(Base)))"));
        assert(me.equals("p\n" +"g1(i1 + p)\n" +"g2 . g1(i2 + i1 + p)\n" +"g3 . g2 . g1(i3 + i2 + i1 + p)"));
        assert(p.equals("g3g2g1i3 + g3g2g1i2 + g3g2g1i1 + g3g2g1p"));
    }
    
   @Test
    public void AllTogetherNow(){
        m.clearModuleExpression();
        m.setModelType("Ahead", true);
        m.applyQuark();
        m.setModelType("AspectJ", true);
        m.applyQuark();
        m.setModelType("Aspectual Mixin Layers++", true);
        m.applyQuark();
        m.setModelType("General",true);
        m.applyQuark();
        String fe = m.getFeatureExpression();
        String me = m.getModuleExpression();
        String p  = m.getProgram();
        assert(fe.equals("F4(F3(F2(F1(Base))))"));
        assert(me.equals("p\n" +"i1 + a1(p)\n" + "g2(i2 + i1 + a1(p))\n" +
               "g3 . h3[g2](i3 + i2 + i1 + h3[a1](p))\n" +
               "g4 . h4[g3 . h3[g2]](i4 + a4(i3 + i2 + i1 + h4 * h3[a1](p)))"));
        assert(p.equals("g4h4g3h4h3g2i4 + g4h4g3h4h3g2a4i3 + g4h4g3h4h3g2a4i2 + g4h4g3h4h3g2a4i1 + g4h4g3h4h3g2a4h4h3a1p"));
    }
}
