package quark;

public class Visitor {
	   public static final Visitor singleton = new Visitor();    // use this as the lone visitor object

	public tree visit( A quark_a, I i ) {
	      System.out.println( "cannot apply introduction to A node" );
	      System.exit(1);
	      return null;
	   }

	public tree visit( G quark_g, I i ) {
	      System.out.println( "cannot apply introduction to A node" );
	      System.exit(1);
	      return null;
	   }

	public tree visit( H quark_h, I i ) {
	      System.out.println( "cannot apply introduction to higher order advice" );
	      System.exit(1);
	      return null;
	   }

	public tree visit( advprog advprog, I i ) { return new intsum( i, advprog ); }

	public tree visit( intro intro, I i ) { return new intsum( i, intro ); }

	public tree visit(gadvprog gadvprog, I i) { return new gadvprog( gadvprog.left, (I) gadvprog.right.accept(Visitor.singleton, i)); }

	public tree visit( intsum intsum, I i ) { return new intsum( i, intsum ); }
}
