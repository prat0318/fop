package quark;

abstract class G extends tree {

   // set of default methods common to advice
   // may be overridden by specific types
 
   /**
 * @deprecated Use {@link quark.Visitor#visit(A, I)} instead
 */
public tree accept( Visitor v, I i ) {
	return v.visit(this, i);
}

   public tree apply( A a ) {
      System.out.println( "cannot apply local advice to G node" );
      System.exit(1);
      return null;
   }
}
