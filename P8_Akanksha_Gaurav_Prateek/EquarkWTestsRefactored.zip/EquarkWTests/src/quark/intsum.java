package quark;

class intsum extends I {
   I left;
   I right;

   intsum( I left, I right ) { this.left = left; this.right = right; }

   /**
 * @deprecated Use {@link quark.Visitor#visit(quark.intsum,I)} instead
 */
public tree accept( Visitor v, I i ) {
	return v.visit(this, i);
}

   public tree apply( A a ) { return new advprog( a, this ); }

   public tree apply( G g ) { return new gadvprog( g, this ); }

   public tree apply( H h ) { 
      return new intsum( (I) left.apply(h), (I) right.apply(h) ); 
   }

   public String toString() { return left + " + " + right; }

   public String eval( String fnc ) { 
      return left.eval(fnc) + " + " + right.eval(fnc); }
}
